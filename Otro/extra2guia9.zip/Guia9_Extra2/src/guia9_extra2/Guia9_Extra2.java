package guia9_extra2;

import AhorcadoService.AhorcadoService;

public class Guia9_Extra2 {

    public static void main(String[] args) {
        AhorcadoService juego = new AhorcadoService();
        juego.crearJuego();
        juego.longitud();
        juego.buscar();
        juego.encontradas();
    }

}
